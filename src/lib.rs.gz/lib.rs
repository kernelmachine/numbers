#![allow(dead_code)]
#![allow(unused_variables)]

extern crate lapack;
extern crate blas;
extern crate rand;

use rand::{thread_rng, Rng};
use std::iter::*;

#[derive(Debug, Clone)]
pub struct Matrix {
    elements : Vec<f64>,
    row_size : usize,
    col_size : usize,
    transpose :  bool,
}

impl PartialEq for Matrix {
    fn eq(&self, other: &Matrix) -> bool {
         (self.elements == other.elements)
       & (self.row_size == other.row_size)
       & (self.col_size == other.col_size)
       & (self.transpose  == other.transpose)
   }
}

impl Matrix{
    // create new Matrix
    fn new(e : Vec<f64>, r_size : usize, c_size : usize) -> Matrix{
        if r_size * c_size != e.len(){
            panic!("dimensions do not match length of vector.")
        }

        Matrix {
            elements : e,
            row_size : r_size,
            col_size : c_size,
            transpose : false,
        }

    }

    // creates matrix of zeros
    fn zeros(r_size : usize, c_size : usize) -> Matrix{
        Matrix {
            elements : repeat(0.0)
            .take(r_size*c_size)
            .collect::<Vec<f64>>(),
            row_size : r_size,
            col_size : c_size,
            transpose : false,
        }

    }

    // creates matrix of random elements
    fn random(r_size : usize, c_size : usize) -> Matrix{
        Matrix {
            elements : rand::thread_rng()
            .gen_iter::<f64>()
            .take(r_size*c_size)
            .collect::<Vec<f64>>(),
            row_size : r_size,
            col_size : c_size,
            transpose : false,
        }

    }

    // map index in matrix to index in 1-d vector
    fn get_ind(&self, row :usize, col : usize) -> usize{
        if self.transpose == true{
            return (row-1)+ (col-1)*self.row_size
        }
        return (col-1) +(row-1)*self.col_size
    }

    // get an element from the matrix
    fn get_element(&self, row : usize, col : usize) -> f64{
        return self.elements[self.get_ind(row,col)]
    }


    // transpose matrix. We're not actually changing anything in memory.
    // we just flag the matrix as transpose to change pointer reference to elements.
    fn transpose(&self) -> Matrix {
        Matrix {
            elements : self.elements.to_owned(),
            row_size : self.col_size,
            col_size : self.row_size,
            transpose : match self.transpose { true => false, false => true}
        }

    }

    // get a submatrix from a matrix.
    fn submatrix(&self, start : (usize,usize), dim : (usize,usize)) -> Matrix {
    unimplemented!();
    }
}


mod lp {
    use super::Matrix;
    use lapack::*;

    // get the eigenvalues of a matrix. This is not finished.
    pub fn eigenvalues(a : &mut Matrix) -> Vec<f64>{
        let n = a.row_size;
        let mut w = vec![0.0; n];
        let mut work = vec![0.0; 4 * n];
        let lwork = 4 * n as isize;
        let mut info = 0;
        dsyev(b'V', b'U', n, &mut a.elements, n, &mut w, &mut work, lwork, &mut info);
        return w
    }

}

#[cfg(test)]
mod tests{
    use super::Matrix;
    use super::lp::eigenvalues;

    #[test]
    fn test_zeros() {
        let row_size = 2;
        let column_size = 2;
        let mat = Matrix::zeros(row_size,column_size);
        assert_eq!(mat.elements, [0.0,0.0,0.0,0.0])
    }

    #[test]
    fn test_get_element() {
        let row_size = 2;
        let column_size = 2;
        let mat = Matrix :: new(vec![1.0,2.0,3.0,4.0],row_size,column_size);
        let element = mat.get_element(1,2);
        assert_eq!(2.0, element);
        let element = mat.transpose().get_element(1,2);
        assert_eq!(3.0, element)
    }

    #[test]
    fn test_transpose() {
        let row_size = 2;
        let column_size = 2;
        let mat = Matrix :: new(vec![1.0,2.0,3.0,4.0],row_size,column_size);
        let mat_t = mat.transpose().transpose();
        assert_eq!(mat_t,mat)
    }

    #[test]
    fn test_eigenvalues() {
        let mat = Matrix :: new(vec![3.0, 1.0, 1.0, 1.0, 3.0, 1.0, 1.0, 1.0, 3.0], 3,3);
        let w = eigenvalues(&mut mat.to_owned());

        //tests will probably have to incorporate some semblence of error < eps...
        for (one, another) in w.iter().zip(&[2.0, 2.0, 5.0]) {
                assert!((one - another).abs() < 1e-14);
            }
    }
}
